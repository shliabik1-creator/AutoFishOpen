package ru.autofish.open

import android.graphics.Bitmap

/** Visual detector for the fishing minigame shown in the user's recording. */
enum class FishState { IDLE, CHARGE, RAPID_TAP, PERFECT, RESULT, UNKNOWN }

data class DetectionResult(val state: FishState, val confidence: Float, val note: String)

class FishStateDetector {
    fun analyzeFrame(bitmap: Bitmap, recognizedText: String): DetectionResult {
        val text = recognizedText.uppercase()
        if (text.contains("PERFECT")) return DetectionResult(FishState.PERFECT, 0.96f, "Распознано PERFECT")
        if (text.contains("НАГРАД") || text.contains("VOID PEARL") || text.contains("ПОЛУЧЕНО"))
            return DetectionResult(FishState.RESULT, 0.88f, "Похоже на экран награды")

        val w = bitmap.width
        val h = bitmap.height
        if (w < 10 || h < 10) return DetectionResult(FishState.UNKNOWN, 0f, "Кадр слишком маленький")

        // In the supplied Roblox recording the rapid-tap minigame has a long,
        // bright-green horizontal meter near the bottom-centre of the landscape screen.
        // Requiring a continuous run avoids reacting to small green HUD labels/buttons.
        val meterGreen = maxGreenPixelsInRow(bitmap,
            (w * 0.28f).toInt(), (w * 0.70f).toInt(),
            (h * 0.86f).toInt(), (h * 0.96f).toInt())
        if (meterGreen >= w * 0.18f)
            return DetectionResult(FishState.RAPID_TAP, 0.91f, "Обнаружена длинная зелёная шкала мини-игры")

        if (text.contains("НАЖИМАЙТЕ") || text.contains("БЫСТРО") || text.contains("TAP QUICKLY"))
            return DetectionResult(FishState.RAPID_TAP, 0.88f, "Распознана подсказка мини-игры")
        if (text.contains("ЗАРЯД") || text.contains("CHARGE"))
            return DetectionResult(FishState.CHARGE, 0.84f, "Распознана шкала заряда")

        return DetectionResult(FishState.UNKNOWN, 0.2f, "Кадр получен; игровое состояние не определено")
    }

    private fun maxGreenPixelsInRow(bitmap: Bitmap, left: Int, right: Int, top: Int, bottom: Int): Int {
        val x0 = left.coerceIn(0, bitmap.width - 1)
        val x1 = right.coerceIn(x0 + 1, bitmap.width)
        val y0 = top.coerceIn(0, bitmap.height - 1)
        val y1 = bottom.coerceIn(y0 + 1, bitmap.height)
        var maxCount = 0
        // Sample several rows inside the meter, ignoring its dark border.
        // The central decorative fish icon splits the green meter into two segments,
        // so count green pixels across the whole row instead of requiring one run.
        val rows = 9
        for (i in 0 until rows) {
            val y = y0 + ((y1 - y0 - 1) * i / (rows - 1).coerceAtLeast(1))
            var count = 0
            for (x in x0 until x1) {
                val c = bitmap.getPixel(x, y)
                val r = (c shr 16) and 255
                val g = (c shr 8) and 255
                val b = c and 255
                if (g > 135 && g > r * 1.28f && g > b * 1.12f) count++
            }
            if (count > maxCount) maxCount = count
        }
        return maxCount
    }
}
