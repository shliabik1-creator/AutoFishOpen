package ru.autofish.open

/**
 * Placeholder for OpenCV-based visual state detection.
 * States are inferred from screen pixels, not from Roblox internals.
 */
enum class FishState { IDLE, CAST_PROMPT, CHARGE, WAITING_FOR_BITE, RAPID_TAP, RESULT, UNKNOWN }

data class DetectionResult(
    val state: FishState,
    val confidence: Float,
    val note: String
)

class FishStateDetector {
    fun analyzeFrame(/* bitmap: Bitmap */): DetectionResult {
        // TODO: Calibrate regions and templates from user-provided gameplay recording.
        return DetectionResult(FishState.UNKNOWN, 0f, "Калибровка кадров ещё не выполнена")
    }
}
