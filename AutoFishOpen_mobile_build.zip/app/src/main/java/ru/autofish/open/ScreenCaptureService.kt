package ru.autofish.open

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        const val ACTION_ANALYSIS = "ru.autofish.open.ANALYSIS"
        const val EXTRA_STATE = "state"
        const val EXTRA_NOTE = "note"
        private const val CHANNEL_ID = "autofish_capture"
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var handler: Handler? = null
    private val busy = AtomicBoolean(false)
    private val detector = FishStateDetector()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    @Volatile private var autoEnabled = false
    private var rapidTapConfirmations = 0
    private val tapHandler = Handler(Looper.getMainLooper())
    @Volatile private var tapLoopActive = false
    private val tapRunnable = object : Runnable {
        override fun run() {
            if (!tapLoopActive || !autoEnabled) return
            // The accessibility service dispatches a short tap at the screen centre.
            AutoTouchService.tapScreenCenter()
            tapHandler.postDelayed(this, 110L)
        }
    }

    private val toggleReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            autoEnabled = intent?.getBooleanExtra(FloatingPanelService.EXTRA_ENABLED, false) ?: false
            if (!autoEnabled) {
                rapidTapConfirmations = 0
                stopTapLoop()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel(CHANNEL_ID, "AutoFish screen analysis", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        autoEnabled = getSharedPreferences("autofish", MODE_PRIVATE).getBoolean("enabled", false)
        val filter = IntentFilter(FloatingPanelService.ACTION_AUTOFISH_TOGGLE)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(toggleReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(toggleReceiver, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("AutoFish Open")
            .setContentText("Анализ кадров экрана включён")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(41, notification)
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = intent?.parcelableIntent(EXTRA_DATA)
        if (data != null && projection == null) startCapture(code, data)
        return START_NOT_STICKY
    }

    private fun startCapture(code: Int, data: Intent) {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        worker = HandlerThread("AutoFishFrames").also { it.start() }
        handler = Handler(worker!!.looper)
        val manager = getSystemService(MediaProjectionManager::class.java)
        projection = manager.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopCapture() }
        }, handler)
        imageReader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (!busy.compareAndSet(false, true)) { image.close(); return@setOnImageAvailableListener }
            val bitmap = imageToBitmap(image)
            image.close()
            if (bitmap == null) { busy.set(false); return@setOnImageAvailableListener }
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { visionText ->
                    val result = detector.analyzeFrame(bitmap, visionText.text)
                    updateAutoTap(result)
                    sendBroadcast(Intent(ACTION_ANALYSIS).setPackage(packageName)
                        .putExtra(EXTRA_STATE, result.state.name)
                        .putExtra(EXTRA_NOTE, buildStatusNote(result)))
                }
                .addOnFailureListener {
                    val result = detector.analyzeFrame(bitmap, "")
                    updateAutoTap(result)
                    sendBroadcast(Intent(ACTION_ANALYSIS).setPackage(packageName)
                        .putExtra(EXTRA_STATE, result.state.name)
                        .putExtra(EXTRA_NOTE, buildStatusNote(result)))
                }
                .addOnCompleteListener { bitmap.recycle(); busy.set(false) }
        }, handler)
        virtualDisplay = projection?.createVirtualDisplay("AutoFishOpen", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader?.surface, null, handler)
        sendBroadcast(Intent(ACTION_ANALYSIS).setPackage(packageName)
            .putExtra(EXTRA_STATE, "UNKNOWN").putExtra(EXTRA_NOTE, "Захват экрана запущен; ожидаю кадры"))
    }

    private fun updateAutoTap(result: DetectionResult) {
        if (!autoEnabled) {
            rapidTapConfirmations = 0
            stopTapLoop()
            return
        }
        if (result.state == FishState.RAPID_TAP && result.confidence >= 0.85f) {
            rapidTapConfirmations++
            // Require two consecutive positive frames before sending any game input.
            if (rapidTapConfirmations >= 2) startTapLoop()
        } else {
            rapidTapConfirmations = 0
            stopTapLoop()
        }
    }

    private fun startTapLoop() {
        tapHandler.post {
            if (autoEnabled && !tapLoopActive && AutoTouchService.isConnected()) {
                tapLoopActive = true
                tapRunnable.run()
            }
        }
    }

    private fun stopTapLoop() {
        tapHandler.post {
            tapLoopActive = false
            tapHandler.removeCallbacks(tapRunnable)
        }
    }

    private fun buildStatusNote(result: DetectionResult): String {
        val base = "${result.note} • уверенность ${(result.confidence * 100).toInt()}%"
        if (!autoEnabled) return "$base • авторыбалка выключена"
        if (!AutoTouchService.isConnected()) return "$base • включи службу специальных возможностей"
        return if (result.state == FishState.RAPID_TAP) "$base • автонажатия по центру" else "$base • ожидание мини-игры"
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]
            val pixelStride = plane.pixelStride
            val rowPadding = plane.rowStride - pixelStride * image.width
            val paddedWidth = image.width + rowPadding / pixelStride
            val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
            val buffer = plane.buffer
            buffer.rewind(); padded.copyPixelsFromBuffer(buffer)
            Bitmap.createBitmap(padded, 0, 0, image.width, image.height).also { padded.recycle() }
        } catch (_: Exception) { null }
    }

    private fun stopCapture() {
        autoEnabled = false
        stopTapLoop()
        virtualDisplay?.release(); virtualDisplay = null
        imageReader?.close(); imageReader = null
        projection = null
        worker?.quitSafely(); worker = null; handler = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        stopCapture()
        try { unregisterReceiver(toggleReceiver) } catch (_: Exception) { }
        recognizer.close()
        super.onDestroy()
    }
}

@Suppress("DEPRECATION")
private fun Intent.parcelableIntent(key: String): Intent? =
    if (Build.VERSION.SDK_INT >= 33) getParcelableExtra(key, Intent::class.java) else getParcelableExtra(key)
