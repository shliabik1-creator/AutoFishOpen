package ru.autofish.open

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class AutoTouchService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* Game-state events are not used as a substitute for visual detection. */ }
    override fun onInterrupt() {}

    fun tap(x: Float, y: Float, durationMs: Long = 70L) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
