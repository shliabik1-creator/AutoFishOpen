package ru.autofish.open

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.util.DisplayMetrics
import android.view.accessibility.AccessibilityEvent
import android.view.WindowManager

/**
 * Accessibility bridge used only after the user enables AutoFish in the floating panel.
 * Taps the middle of the display so it avoids the game's side HUD controls.
 */
class AutoTouchService : AccessibilityService() {
    companion object {
        @Volatile private var activeService: AutoTouchService? = null

        fun isConnected(): Boolean = activeService != null

        fun tapScreenCenter(): Boolean = activeService?.dispatchCenterTap() ?: false
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeService = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { }

    private fun dispatchCenterTap(): Boolean {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val x = metrics.widthPixels / 2f
        val y = metrics.heightPixels / 2f
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 45L))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    override fun onDestroy() {
        if (activeService === this) activeService = null
        super.onDestroy()
    }
}
