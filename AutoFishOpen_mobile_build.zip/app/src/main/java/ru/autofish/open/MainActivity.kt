package ru.autofish.open

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val captureRequest = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
            }
            startForegroundService(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var running by remember { mutableStateOf(false) }
                var state by remember { mutableStateOf("Ожидание") }
                var note by remember { mutableStateOf("Разреши захват экрана, затем открой Roblox.") }
                DisposableEffect(Unit) {
                    val receiver = object : BroadcastReceiver() {
                        override fun onReceive(context: Context?, intent: Intent?) {
                            state = intent?.getStringExtra(ScreenCaptureService.EXTRA_STATE) ?: "UNKNOWN"
                            note = intent?.getStringExtra(ScreenCaptureService.EXTRA_NOTE) ?: "Кадр обработан"
                            running = true
                        }
                    }
                    val filter = IntentFilter(ScreenCaptureService.ACTION_ANALYSIS)
                    if (Build.VERSION.SDK_INT >= 33) {
                        registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
                    } else {
                        @Suppress("DEPRECATION")
                        registerReceiver(receiver, filter)
                    }
                    onDispose { unregisterReceiver(receiver) }
                }
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("AUTOFISH OPEN", style = MaterialTheme.typography.headlineMedium)
                        Text("Roblox • Android • визуальный тест")
                        Text("Сначала разреши захват экрана. Открой Roblox и оставь эту службу работать в фоне.")
                        Button(onClick = {
                            val manager = getSystemService(MediaProjectionManager::class.java)
                            captureRequest.launch(manager.createScreenCaptureIntent())
                        }) { Text("Разрешить захват экрана") }
                        Button(onClick = { startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                            Text("Настроить управление касаниями")
                        }
                        Button(onClick = {
                            if (Settings.canDrawOverlays(this@MainActivity)) {
                                startService(Intent(this@MainActivity, FloatingPanelService::class.java))
                            } else {
                                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:$packageName")))
                            }
                        }) { Text("Показать плавающую панель") }
                        if (running) Button(onClick = {
                            stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                            running = false; state = "STOP"; note = "Анализ остановлен"
                        }) { Text("STOP — остановить анализ") }
                        Text("Состояние: $state", style = MaterialTheme.typography.titleMedium)
                        Text(note)
                        Text("Авторыбалка нажимает по центру экрана только после распознавания зелёной шкалы мини-игры. Включай её плавающей кнопкой СТАРТ.")
                    }
                }
            }
        }
    }
}
