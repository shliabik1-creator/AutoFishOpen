package ru.autofish.open

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val captureRequest = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
            }
            startForegroundService(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                var running by remember { mutableStateOf(false) }
                var status by remember { mutableStateOf("Готово к настройке") }
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("AUTOFISH OPEN", style = MaterialTheme.typography.headlineMedium)
                        Text("Roblox • Android 16 • OpenCV")
                        Text("Сначала разреши захват экрана и службу специальных возможностей.")
                        Button(onClick = {
                            val manager = getSystemService(MediaProjectionManager::class.java)
                            captureRequest.launch(manager.createScreenCaptureIntent())
                            status = "Ожидание разрешения на захват экрана"
                        }) { Text("Разрешить захват экрана") }
                        Button(onClick = {
                            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                            status = "Включи AutoFish Open в специальных возможностях"
                        }) { Text("Настроить управление касаниями") }
                        Button(onClick = {
                            running = !running
                            status = if (running) "Режим анализа включён" else "Остановлено"
                        }) { Text(if (running) "STOP" else "START") }
                        Text("Состояние: $status")
                        Text("Детектор и игровой автомат состояний будут подключены после проверки реальных кадров.")
                    }
                }
            }
        }
    }
}
