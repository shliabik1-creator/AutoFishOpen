package ru.autofish.open

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import kotlin.math.roundToInt

/**
 * Извините за прежнюю ошибку со сборкой: workflow теперь находит ZIP независимо от имени.
 * Draggable on-screen control panel.
 * The ON switch currently enables the diagnostic/automation-ready flag only;
 * it does not perform game taps until a verified fishing controller is implemented.
 */
class FloatingPanelService : Service() {
    companion object {
        const val ACTION_AUTOFISH_TOGGLE = "ru.autofish.open.AUTOFISH_TOGGLE"
        const val EXTRA_ENABLED = "enabled"
    }

    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private var enabled = false
    private var status: TextView? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createPanel()
    }

    private fun createPanel() {
        val prefs = getSharedPreferences("floating_panel", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(225, 28, 22, 52))
                cornerRadius = dp(22).toFloat()
                setStroke(dp(2), Color.argb(220, 220, 210, 255))
            }
        }
        val header = TextView(this).apply {
            text = "🐟  AutoFishOpen   ⋮"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), dp(2), dp(4), dp(8))
        }
        root.addView(header)
        status = TextView(this).apply {
            text = "Диагностика выключена"
            setTextColor(Color.WHITE)
            textSize = 12f
            setPadding(dp(4), 0, dp(4), dp(6))
        }
        root.addView(status)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = Button(this).apply {
            text = "▶ СТАРТ"
            setOnClickListener {
                enabled = true
                status?.text = "Режим включён (диагностика)"
                sendToggle(true)
            }
        }
        val stop = Button(this).apply {
            text = "■ СТОП"
            setOnClickListener {
                enabled = false
                status?.text = "Режим выключен"
                sendToggle(false)
            }
        }
        row.addView(start, LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(stop, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(row)

        val close = TextView(this).apply {
            text = "Закрыть панель"
            setTextColor(Color.LTGRAY)
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, 0)
            setOnClickListener { stopSelf() }
        }
        root.addView(close)

        header.setOnTouchListener(DragTouchListener())
        params = WindowManager.LayoutParams(
            dp(270), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("x", dp(16))
            y = prefs.getInt("y", dp(100))
        }
        panel = root
        wm.addView(root, params)
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).roundToInt()
                    params.y = startY + (e.rawY - touchY).roundToInt()
                    panel?.let { wm.updateViewLayout(it, params) }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    getSharedPreferences("floating_panel", MODE_PRIVATE).edit()
                        .putInt("x", params.x).putInt("y", params.y).apply()
                    return true
                }
            }
            return false
        }
    }

    private fun sendToggle(on: Boolean) {
        sendBroadcast(Intent(ACTION_AUTOFISH_TOGGLE).setPackage(packageName).putExtra(EXTRA_ENABLED, on))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
