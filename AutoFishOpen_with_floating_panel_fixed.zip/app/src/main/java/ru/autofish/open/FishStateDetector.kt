package ru.autofish.open

import android.graphics.Bitmap
import com.google.mlkit.vision.text.Text

/** Visual-only detector. It deliberately does not trigger game input. */
enum class FishState { IDLE, CHARGE, RAPID_TAP, PERFECT, RESULT, UNKNOWN }

data class DetectionResult(val state: FishState, val confidence: Float, val note: String)

class FishStateDetector {
    fun analyzeFrame(bitmap: Bitmap, recognizedText: String): DetectionResult {
        val text = recognizedText.uppercase()
        if (text.contains("PERFECT")) return DetectionResult(FishState.PERFECT, 0.94f, "Распознано PERFECT")
        if (text.contains("НАГРАД") || text.contains("VOID PEARL") || text.contains("ПОЛУЧЕНО"))
            return DetectionResult(FishState.RESULT, 0.82f, "Похоже на экран награды")

        val w = bitmap.width
        val h = bitmap.height
        if (w < 10 || h < 10) return DetectionResult(FishState.UNKNOWN, 0f, "Кадр слишком маленький")

        // The supplied recording shows the charge gauge near the horizontal centre,
        // and the rapid-tap progress bar along the lower edge. Use normalized ROIs.
        val verticalGreen = greenRatio(bitmap, w * 0.43f, h * 0.16f, w * 0.62f, h * 0.73f)
        val bottomGreen = greenRatio(bitmap, w * 0.18f, h * 0.76f, w * 0.78f, h * 0.98f)
        if (bottomGreen > 0.055f)
            return DetectionResult(FishState.RAPID_TAP, 0.72f, "Обнаружена зелёная полоса мини-игры")
        if (verticalGreen > 0.035f)
            return DetectionResult(FishState.CHARGE, 0.68f, "Обнаружена вертикальная зелёная шкала")
        if (text.contains("ЗАРЯД")) return DetectionResult(FishState.CHARGE, 0.85f, "Распознана надпись ЗАРЯД")
        if (text.contains("НАЖИМАЙТЕ") || text.contains("БЫСТРО"))
            return DetectionResult(FishState.RAPID_TAP, 0.86f, "Распознана подсказка мини-игры")
        return DetectionResult(FishState.UNKNOWN, 0.2f, "Кадр получен; игровое состояние не определено")
    }

    private fun greenRatio(bitmap: Bitmap, leftF: Float, topF: Float, rightF: Float, bottomF: Float): Float {
        val left = (bitmap.width * leftF).toInt().coerceIn(0, bitmap.width - 1)
        val right = (bitmap.width * rightF).toInt().coerceIn(left + 1, bitmap.width)
        val top = (bitmap.height * topF).toInt().coerceIn(0, bitmap.height - 1)
        val bottom = (bitmap.height * bottomF).toInt().coerceIn(top + 1, bitmap.height)
        var green = 0
        var total = 0
        val stepX = ((right - left) / 80).coerceAtLeast(1)
        val stepY = ((bottom - top) / 80).coerceAtLeast(1)
        for (y in top until bottom step stepY) for (x in left until right step stepX) {
            val c = bitmap.getPixel(x, y)
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            if (g > 125 && g > r * 1.22 && g > b * 1.08) green++
            total++
        }
        return if (total == 0) 0f else green.toFloat() / total
    }
}
